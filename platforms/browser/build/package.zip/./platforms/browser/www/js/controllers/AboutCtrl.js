app.controller('AboutCtrl', ['$scope', function($scope) {
}])